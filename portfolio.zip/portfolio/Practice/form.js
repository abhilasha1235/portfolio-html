const form = document.getElementById("form");
const email= document.getElementById("email");
const password = document.getElementById("password");

form.addEventListener("button",()=>{
    alert(mai kam kr raha hu);
})