// fullname = "Ravi";  // ab 'name' variable mein "Ravi" store ho gaya hai
// age = 30;
// console.log(fullname, age)




// Arithmetic Operators Example
// let a = 3;
// let x = (100 + 50) +a;
// console.log(x   )

// let text1 = "c";
// let text2 = "B";
// let result = text1 < text2;
// console.log(result)


// let text1 = "abhi";
// let text2 = "lasha";
// let text3 = text1+text2;
// console.log(text3);

//Arithmetic Operations
//let x = 100 + 50;
// console.log(x);

//  let a= 100;
//  let b= 50 ;
// let x = a + b;
// console.log(x);
// let a = 3
// let x = (100 + 50) * a;
// console.log(x);


//Adding
// let x = 5;
// let y = 2;
// let z = x + y;
// console.log(z);


//Subtracting

// let x = 5 ;
// let y = 2;
// let z = x - y ;
// console.log(z);

/*Multiplying
The multiplication operator (*) multiplies numbers.
*/

// let x = 5;
// let y= 2 ;
// let z = x * y;
// console.log(z)

// Dividing
// The division operator (/) divides numbers.
// let x = 5;
// let y = 2 ;
// let z = x /y;
// console.log(z);
// Remainder
// The modulus operator (%) returns the division remainder.

// Example
// let x = 5 ;
// let y = 2;
// let z = x%y;
// console.log(z);

// Incrementing
// The increment operator(++) increments numbers.

// let x = 5;
// x++;
// let z = x;
// console.log(z);

// Decrementing
// The decrement operator (--) decrements numbers.
// let x = 5;
// x--;
// let z = x;
// console.log (z);

// Exponentiation
// The exponentiation operator( ** ) raises the first operand to the power of
//  the second operand.
// let x = 5;
// let z = x ** 2;
// console.log(z);

// x ** y produces the same result as Math.pow(x,y):
// let x = 5;
// let z = Math.pow(x, 2);
// console.log(z);

// Operator Precedence
// let x = 100 + 50 * 3;
// console.log(x);
// addition and multiplication
// let x = (100 + 50) * 3;
// console.log(x);
// let x = (100 + 50) - 3;
// console.log(x);
let x = (100 + 50) / 3;
console.log(x);